CREATE TABLE arj (
    id INT NOT NULL AUTO_INCREMENT,
    member_id INT NOT NULL,
    plan_id INT NOT NULL,
    date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    folio_number VARCHAR(30) NOT NULL DEFAULT '',
    amount INT NOT NULL DEFAULT 0,
    category_id INT NOT NULL,
    PRIMARY KEY (id)
);