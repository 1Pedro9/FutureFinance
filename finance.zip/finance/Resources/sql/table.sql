CREATE TABLE tables(
 	id INT NOT NULL AUTO_INCREMENT,
    plan_id INT NOT NULL,
    member_id INT NOT NULL,
    table_name VARCHAR(10) NOT NULL,
    PRIMARY KEY(id)
)