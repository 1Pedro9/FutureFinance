CREATE TABLE ar (
    member_id INT NOT NULL,
    plan_id INT NOT NULL,
    date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    folio_number VARCHAR(30) NOT NULL DEFAULT '',
    details VARCHAR(100) NOT NULL DEFAULT '',
    category_id INT NOT NULL,
    PRIMARY KEY (folio_number)
);