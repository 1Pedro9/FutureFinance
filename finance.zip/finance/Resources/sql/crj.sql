CREATE TABLE crj (
    id INT NOT NULL AUTO_INCREMENT,
    member_id INT NOT NULL,
    plan_id INT NOT NULL,
    date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    details VARCHAR(100) NOT NULL DEFAULT '',
    folio_number VARCHAR(30) NOT NULL DEFAULT '',
    amount INT NOT NULL DEFAULT 0,
    column_1 INT DEFAULT NULL,
    column_2 INT DEFAULT NULL,
    diverse_amount INT DEFAULT NULL,
    diverse_detail VARCHAR(100) DEFAULT NULL,
    category_id INT NOT NULL,
    PRIMARY KEY (id)
);