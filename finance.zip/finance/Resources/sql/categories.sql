CREATE TABLE categories(
	category_id INT NOT NULL AUTO_INCREMENT,
    category VARCHAR(100) NOT NULL,
    color VARCHAR(10) DEFAULT "#333333",
    member_id INT NOT NULL,
    plan_id INT NOT NULL,
    table_name VARCHAR(10) NOT NULL,
    PRIMARY KEY(category_id)
)