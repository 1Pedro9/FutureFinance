<?php
    
    session_start();
    // require("../objects/financial_objects.php");

    $member_id = $_SESSION['member_id'];
    $plan_id = $_SESSION['plan_id'];
    $table = "cpj";
    $sql = "
        SELECT *
        FROM columns
        WHERE member_id = $member_id AND plan_id = $plan_id AND table_name = '$table'
    ";
    global $con;
    $retval = mysqli_query($con, $sql);
    $row = mysqli_fetch_array($retval, MYSQLI_ASSOC);
    
    $string = '
        <div id="' . $table . '">
            <h1>Cash Paid Journal</h1> 
            <table class="table">
                <tr class="heading">
                    <th hidden></th>
                    <th class="action"></th>
                    <th class="year">Year</th>
                    <th class="month">Month</th>
                    <th class="day">Day</th>
                    <th class="details">Details</th>
                    <th class="fol">FOL</th>
                    <th class="amount">Amount</th>
                    <th class="column-1" onclick="open_columns(this)">' . $row['column_1'] . '</th>
                    <th class="column-2" onclick="open_columns(this)">' . $row['column_2'] . '</th>
                    <th class="diverse-amount">Amount</th>
                    <th class="diverse-details">Details</th>
                </tr>
    ';

    $sql = "
        SELECT id 
        FROM $table
        WHERE member_id = $member_id AND plan_id = $plan_id
        ORDER BY date, id
    ";
    global $con;
    $retval = mysqli_query($con, $sql);
    $objects = array();
    while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)){
        $id = $row['id'];
        $object = new Journal($id, $table);
        $objects[] = $object;
    }
    $current_year = "";
    $current_month = "";
    $current_day = "";
    $prev_year = "";
    $prev_month = "";
    $prev_day = "";
    $is_first = false;
    foreach($objects as $obj){
        $current_month = $obj->getMonth();
        $current_year = $obj->getYear();
        $current_day = $obj->getDay();
        
        if(($prev_year != $current_year || $prev_month != $current_month) && $is_first){
            $string .= add($prev_year, $prev_month, $prev_day);
            $string .= total($prev_year, $prev_month);
            $string .= empty_row();
        }
        
        $string .= main($obj);
       
        $prev_year = $current_year;
        $prev_month = $current_month;
        $prev_day = $current_day;
        $is_first = true;
    }
    if(sizeof($objects) < 1){
        $string .= add(date("Y"), date("m"), date("d"));
    }
    else {
        $string .= add($current_year, $current_month, $current_day);
        $string .= total($current_year, $current_month);
    }


    $string .= '
            </table>
        </div>    
    ';
    
    echo $string;
    function main($object){
        return '
            <tr class="main-rows target" id="' . $object->getID() . '">
                <th hidden><input type="text" class="category" value="' . $object->getCategory() . '" hidden></th>
                <th class="action">
                    <button class="delete"><span class="material-symbols-outlined">delete</span></button>
                    <button class="edit"><span class="material-symbols-outlined">edit</span></button>
                </th>
                <th class="year"><input type="text" value="' . $object->getYear() . '" readonly></th>
                <th class="month"><input type="text" value="' . $object->getMonth() . '" readonly></th>
                <th class="day"><input type="text" value="' . $object->getDay() . '" readonly></th>
                <th class="details"><input type="text" value="' . $object->getDetails() . '" readonly></th>
                <th class="fol"><input type="text" value="' . $object->getFOL() . '" readonly></th>
                <th class="amount"><input type="text" value="' . round($object->getAmount(), 2) . '" readonly onmouseover="showTooltip(this, `' . $object->getCategory() . '`)"></th>
                <th class="column-1"><input type="text" value="' . round($object->getColumn_1(), 2) . '" readonly></th>
                <th class="column-2"><input type="text" value="' . round($object->getColumn_2(), 2) . '" readonly></th>
                <th class="diverse-amount"><input type="text" value="' . round($object->getDiverseAmount(), 2) . '" readonly></th>
                <th class="diverse-details"><input type="text" value="' . $object->getDiverseDetails() . '" readonly></th>
            </tr>
        ';
    }
    function add($year, $month, $day){
        return '
            <tr class="add-rows">
                <th hidden><input type="text" class="category" value="" hidden></th>
                <th class="action"><button class="add"><span class="material-symbols-outlined">add</span></button></th>
                <th class="year"><input type="text" value="' . $year . '"></th>
                <th class="month"><input type="text" value="' . $month . '"></th>
                <th class="day"><input type="text" value="' . $day . '"></th>
                <th class="details"><input type="text" value="" placeholder="Add Details"></th>
                <th class="fol"><input type="text" value=""></th>
                <th class="amount"><input type="text" value="0"></th>
                <th class="column-1"><input type="text" value="0"></th>
                <th class="column-2"><input type="text" value="0"></th>
                <th class="diverse-amount"><input type="text" value="0"></th>
                <th class="diverse-details"><input type="text" value=""></th>
            </tr>
        ';
    }
    function total($year, $month){
        global $table;
        $sql = "
            SELECT SUM(amount), SUM(column_1), SUM(column_2), SUM(diverse_amount), YEAR(Date), MONTH(Date)
            FROM $table
            WHERE member_id = {$_SESSION['member_id']} AND plan_id = {$_SESSION['plan_id']}
            AND YEAR(Date) = $year AND MONTH(Date) = $month
            GROUP BY YEAR(Date), MONTH(Date)
        ";
        global $con;
        $retval = mysqli_query($con, $sql);

        $row = mysqli_fetch_array($retval, MYSQLI_ASSOC);

        return '
            <tr class="total-rows">
                <th hidden><input type="text" class="category" hidden></th>
                <th class="action"></th>
                <th class="year"><input type="text" readonly></th>
                <th class="month"><input type="text" readonly></th>
                <th class="day"><input type="text" readonly></th>
                <th class="details"><input type="text" readonly></th>
                <th class="fol"><input type="text" readonly></th>
                <th class="amount"><input type="text" value="' . round($row['SUM(amount)'], 2) . '" readonly></th>
                <th class="column-1"><input type="text" value="' . round($row['SUM(column_1)'], 2) . '" readonly></th>
                <th class="column-2"><input type="text" value="' . round($row['SUM(column_2)'], 2) . '" readonly></th>
                <th class="diverse-amount"><input type="text" value="' . round($row['SUM(diverse_amount)'], 2) . '" readonly></th>
                <th class="diverse-details"><input type="text" readonly></th>
            </tr>
        ';
    }

    function empty_row(){
        return '<tr class="empty"></tr>';
    }

?>