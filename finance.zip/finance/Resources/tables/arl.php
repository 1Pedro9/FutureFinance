<?php
    
    session_start();
    // require("../objects/financial_objects.php");

    $member_id = $_SESSION['member_id'];
    $plan_id = $_SESSION['plan_id'];
    $table = "arl";
    
    $string = '
        <div id="' . $table . '">
            <h1>Accounts Received Ledger</h1> 
    ';
    
    $sql = "
        SELECT *
        FROM categories
        WHERE member_id = $member_id
        AND plan_id = $plan_id
        AND table_name = 'arj'
    ";
    global $con;
    $retval = mysqli_query($con, $sql);
    while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)){
        $total_amount = 0;
        $objects = array();
        
        $string .= '
            <h2>' . $row['category'] . '</h2>
            <table class="table">
                <tr class="heading">
                    <th class="year">Year</th>
                    <th class="month">Month</th>
                    <th class="day">Day</th>
                    <th class="details">Details</th>
                    <th class="fol">FOL</th>
                    <th class="debit">Debit</th>
                    <th class="credit">Credit</th>
                    <th class="balance">Balance</th>
                </tr>
        ';
        
        $sql1 = "
            SELECT id
            FROM arj
            WHERE member_id = $member_id
            AND plan_id = $plan_id
            AND category_id = {$row['category_id']}
        ";
        global $con;
        $retval1 = mysqli_query($con, $sql1);
        while($th = mysqli_fetch_array($retval1, MYSQLI_ASSOC)){
            $object = new Journal($th['id'], "arj");
            $objects[] = $object;
        }
        
        $sql2 = "
            SELECT category_id
            FROM categories
            WHERE member_id = $member_id
            AND plan_id = $plan_id
            AND table_name = 'crj'
            AND category = '{$row['category']}'
        ";
        global $con;
        $retval2 = mysqli_query($con, $sql2);
        $row1 = mysqli_fetch_array($retval2, MYSQLI_ASSOC);
        
        $sql3 = "
            SELECT id
            FROM crj
            WHERE member_id = $member_id
            AND plan_id = $plan_id
            AND category_id = {$row1['category_id']}
        ";
        global $con;
        $retval3 = mysqli_query($con, $sql3);
        while($th = mysqli_fetch_array($retval3, MYSQLI_ASSOC)){
            $object = new Journal($th['id'], "crj");
            $objects[] = $object;
        }
        
        $is_first = true;
        foreach($objects as $obj){
            if($is_first){
                $string .= '
                    <tr class="main-rows">
                        <th class="year"><input type="text" value="' . $obj->getYear() . '" readonly></th>
                        <th class="month"><input type="text" value="' . $obj->getMonth() . '" readonly></th>
                        <th class="day"><input type="text" value="01" readonly></th>
                        <th class="details"><input type="text" value="Balance" readonly></th>
                        <th class="fol"><input type="text" value="B/F" readonly></th>
                        <th class="debit"><input type="text" value="" readonly></th>
                        <th class="credit"><input type="text" value="" readonly></th>
                        <th class="balance"><input type="text" value="0" readonly></th>
                    </tr>
                ';
            }
            
            if($obj->getTable() == "arj"){
                $total_amount += (float) $obj->getAmount();
                $string .= main($obj, $obj->getAmount(), 0, $total_amount);
            }
            else {
                $total_amount -= (float) $obj->getAmount();
                $string .= main(0, $obj->getAmount(), $total_amount);
            }
            
            
            $is_first = false;
        }
        
        $string .= '
            </table>
        ';
    }
    
    
    
    $string .= '
        </div>    
    ';
    
    echo $string;
    
    
    function main($obj, $debit, $credit, $balance){
        return '
            <tr class="main-rows">
                <th class="year"><input type="text" value="' . $obj->getYear() . '" readonly></th>
                <th class="month"><input type="text" value="' . $obj->getMonth() . '" readonly></th>
                <th class="day"><input type="text" value="' . $obj->getDay() . '" readonly></th>
                <th class="details"><input type="text" value="' . $obj->getDetails() . '" readonly></th>
                <th class="fol"><input type="text" value="' . $obj->getFOL() . '" readonly></th>
                <th class="debit"><input type="text" value="' . $debit . '" readonly></th>
                <th class="credit"><input type="text" value="' . $credit . '" readonly></th>
                <th class="balance"><input type="text" value="' . $balance . '" readonly></th>
            </tr>
        ';
    }
    
    function test($debit, $credit, $balance){
        return '
            <tr class="main-rows">
                <th class="year"><input type="text" value"2023" readonly></th>
                <th class="month"><input type="text" value"01" readonly></th>
                <th class="day"><input type="text" value"01" readonly></th>
                <th class="details"><input type="text" value"Balance" readonly></th>
                <th class="fol"><input type="text" value"" readonly></th>
                <th class="debit"><input type="text" value"' . $debit . '" readonly></th>
                <th class="credit"><input type="text" value"' . $credit . '" readonly></th>
                <th class="balance"><input type="text" value"' . $balance . '" readonly></th>
            </tr>
        ';
    }
    
    
?>