<?php
    session_start();

    $table = $_SESSION['menu'];
    $member_id = $_SESSION['member_id'];
    $plan_id = $_SESSION['plan_id'];
    $crj = array();
    $cpj = array();
    $string = "";
    $day_of_months = array("31", "28", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31");
    $total_amount = 0;
    
    $string .= '
        <div id="gl">
            <h1>General Ledger</h1> 
            <table class="table">
                <tr class="heading">
                    <th class="year">Year</th>
                    <th class="month">Month</th>
                    <th class="day">Day</th>
                    <th class="details">Details</th>
                    <th class="fol">FOL</th>
                    <th class="amount">Amount</th>
                    <th class="middle" colspan=""></th>
                    <th class="year-2">Year</th>
                    <th class="month-2">Month</th>
                    <th class="day-2">Day</th>
                    <th class="details-2">Details</th>
                    <th class="fol-2">FOL</th>
                    <th class="amount-2">Amount</th>
                </tr>
    ';
    
    $sql = "
        SELECT SUM(amount), MONTH(date), YEAR(date)
        FROM crj
        WHERE member_id = $member_id AND plan_id = $plan_id
        GROUP BY MONTH(date), YEAR(date)
        ORDER BY date, id
    ";
    global $con;
    $retval = mysqli_query($con, $sql);
    while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)){
        $object = new GL($row['YEAR(date)'], $row['MONTH(date)'], $row['SUM(amount)'], "crj");
        $crj[] = $object;
    }
    $sql = "
        SELECT SUM(amount), MONTH(date), YEAR(date)
        FROM cpj
        WHERE member_id = $member_id AND plan_id = $plan_id
        GROUP BY MONTH(date), YEAR(date)
        ORDER BY date, id
    ";
    global $con;
    $retval = mysqli_query($con, $sql);
    while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)){
        $object = new GL($row['YEAR(date)'], $row['MONTH(date)'], $row['SUM(amount)'], "cpj");
        $cpj[] = $object;
    }
    
    $dates = array();
    
    $sql = "
        SELECT DISTINCT YEAR(date), MONTH(date)
        FROM (
            SELECT date FROM crj WHERE member_id = $member_id AND plan_id = $plan_id
            UNION
            SELECT date FROM cpj WHERE member_id = $member_id AND plan_id = $plan_id
        ) AS combined_dates
        ORDER BY YEAR(date), MONTH(date);
    ";
    global $con;
    $retval = mysqli_query($con, $sql);
    while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)){
        $object = new GL($row['YEAR(date)'], $row['MONTH(date)'], "0", "");
        $dates[] = $object;
    }
    
    
    foreach($dates as $date){
        $year = $date->getYear();
        $month = $date->getMonth();
        $amount_received = 0;
        $amount_paid = 0;
        $total_left = 0;
        $total_right = 0;
        
        $string .= balance_bf($year, $month, $total_amount);
        
        foreach($crj as $received){
            if($year == $received->getYear() && $month == $received->getMonth()){
                $amount_received = (double) $received->getAmount();
            }
        }
        foreach($cpj as $paid){
            if($year == $paid->getYear() && $month == $paid->getMonth()){
                $amount_paid = (double) $paid->getAmount();
            }
        }
        
        $prev = $total_amount;
        if($prev < 0){
            $total_right += $prev;
        }
        else {
            $total_left += $prev;
        }
        
        
        $string .= main($year, $month, $amount_received, $amount_paid);
        $total_amount += ($amount_received - $amount_paid);
        $string .= balance_cf($total_amount);
        
        if($total_amount < 0){
            $help = $amount_paid+$total_right;
            $string .= total("{$help}");
        }
        else {
            $help = $amount_received+$total_left;
            $string .= total("{$help}");
        }
        
        
        $string .= empty_row();
        $string .= empty_row();
        $string .= empty_row();
    }


    $string .= '
            </table>
        </div>
    ';
    
    echo $string;

    function main($year, $month, $amount1, $amount2){
        // $day_of_months = array("31", "28", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31");
        global $day_of_months;
        $day = $day_of_months[($month-1)];
        if($year % 4 == 0 && $month == 2){
            $day = "29";
        }
        return '
            <tr class="main-rows" id="">
                <th class="year"><input type="text" value="' . $year . '" readonly></th>
                <th class="month"><input type="text" value="' . $month . '" readonly></th>
                <th class="day"><input type="text" value="' . $day . '" readonly></th>
                <th class="details"><input type="text" value="Total Cash Received" readonly></th>
                <th class="fol"><input type="text" value="CRJ" readonly></th>
                <th class="amount"><input type="text" value="' . round($amount1, 2) . '" readonly></th>
                <th class="middle" colspan=""></th>
                <th class="year-2"><input type="text" value="' . $year . '" readonly></th>
                <th class="month-2"><input type="text" value="' . $month . '" readonly></th>
                <th class="day-2"><input type="text" value="' . $day . '" readonly></th>
                <th class="details-2"><input type="text" value="Total Cash Paid" readonly></th>
                <th class="fol-2"><input type="text" value="CPJ" readonly></th>
                <th class="amount-2"><input type="text" value="' . round($amount2, 2) . '" readonly></th>    
            </tr>
        ';
    }

    function balance_bf($year, $month, $amount){
        if($amount < 0){
            return '
                <tr class="main-rows  balance-bf-negative" id="">
                    <th class="year"><input type="text" value="" readonly></th>
                    <th class="month"><input type="text" value="" readonly></th>
                    <th class="day"><input type="text" value="" readonly></th>
                    <th class="details"><input type="text" value="Balance" readonly></th>
                    <th class="fol"><input type="text" value="" readonly></th>
                    <th class="amount"><input type="text" value="" readonly></th>
                    <th class="middle" colspan=""></th>
                    <th class="year-2"><input type="text" value="' . $year . '" readonly></th>
                    <th class="month-2"><input type="text" value="' . $month . '" readonly></th>
                    <th class="day-2"><input type="text" value="1" readonly></th>
                    <th class="details-2"><input type="text" value="Balance" readonly></th>
                    <th class="fol-2"><input type="text" value="B/F" readonly></th>
                    <th class="amount-2"><input type="text" value="' . round($amount, 2) . '" readonly></th>    
                </tr>
            ';
        }
        else {
            return '
                <tr class="main-rows  balance-bf" id="">
                    <th class="year"><input type="text" value="' . $year . '" readonly></th>
                    <th class="month"><input type="text" value="' . $month . '" readonly></th>
                    <th class="day"><input type="text" value="1" readonly></th>
                    <th class="details"><input type="text" value="Balance" readonly></th>
                    <th class="fol"><input type="text" value="B/F" readonly></th>
                    <th class="amount"><input type="text" value="' . round($amount, 2) . '" readonly></th>
                    <th class="middle" colspan=""></th>
                    <th class="year-2"><input type="text" value="" readonly></th>
                    <th class="month-2"><input type="text" value="" readonly></th>
                    <th class="day-2"><input type="text" value="" readonly></th>
                    <th class="details-2"><input type="text" value="" readonly></th>
                    <th class="fol-2"><input type="text" value="" readonly></th>
                    <th class="amount-2"><input type="text" value="" readonly></th>    
                </tr>
            ';
        }
        
    }

    function balance_cf($amount){
        if($amount < 0){
            return '
                <tr class="balance-cf">
                    <th class="year"><input type="text" value="" readonly></th>
                    <th class="month"><input type="text" value="" readonly></th>
                    <th class="day"><input type="text" value="" readonly></th>
                    <th class="details"><input type="text" value="Balance" readonly></th>
                    <th class="fol"><input type="text" value="C/F" readonly></th>
                    <th class="amount"><input type="text" value="' . round($amount, 2) . '" readonly></th>
                    <th class="middle" colspan=""></th>
                    <th class="year-2"><input type="text" value="" readonly></th>
                    <th class="month-2"><input type="text" value="" readonly></th>
                    <th class="day-2"><input type="text" value="" readonly></th>
                    <th class="details-2"><input type="text" value="" readonly></th>
                    <th class="fol-2"><input type="text" value="" readonly></th>
                    <th class="amount-2"><input type="text" value="" readonly></th>    
                </tr>
            ';
        }
        else {
            return '
                <tr class="balance-cf">
                    <th class="year"><input type="text" value="" readonly></th>
                    <th class="month"><input type="text" value="" readonly></th>
                    <th class="day"><input type="text" value="" readonly></th>
                    <th class="details"><input type="text" value="" readonly></th>
                    <th class="fol"><input type="text" value="" readonly></th>
                    <th class="amount"><input type="text" value="" readonly></th>
                    <th class="middle" colspan=""></th>
                    <th class="year-2"><input type="text" value="" readonly></th>
                    <th class="month-2"><input type="text" value="" readonly></th>
                    <th class="day-2"><input type="text" value="" readonly></th>
                    <th class="details-2"><input type="text" value="Balance" readonly></th>
                    <th class="fol-2"><input type="text" value="C/F" readonly></th>
                    <th class="amount-2"><input type="text" value="' . round($amount, 2) . '" readonly></th>    
                </tr>
            ';
        }
        
    }

    function total($amount){
        return '
            <tr class="total-rows">
                <th class="year"><input type="text" value="" readonly></th>
                <th class="month"><input type="text" value="" readonly></th>
                <th class="day"><input type="text" value="" readonly></th>
                <th class="details"><input type="text" value="" readonly></th>
                <th class="fol"><input type="text" value="" readonly></th>
                <th class="amount"><input type="text" value="' . round($amount, 2) . '" readonly></th>
                <th class="middle" colspan=""></th>
                <th class="year-2"><input type="text" value="" readonly></th>
                <th class="month-2"><input type="text" value="" readonly></th>
                <th class="day-2"><input type="text" value="" readonly></th>
                <th class="details-2"><input type="text" value="" readonly></th>
                <th class="fol-2"><input type="text" value="" readonly></th>
                <th class="amount"><input type="text" value="' . round($amount, 2) . '" readonly></th>
            </tr>
        ';
    }

    function empty_row(){
        return '<tr class="empty"></tr>';
    }

?>