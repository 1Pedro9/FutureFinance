<?php
    session_start();
    require("../../config.php");

    if(isset($_GET['add-folder'])){
        $folder = $_GET['add-folder'];
        $member_id = $_SESSION['member_id'];
        $plan_id = $_SESSION['plan_id'];
        $sql = "
            SELECT * 
            FROM tables
            WHERE plan_id = $plan_id AND member_id = $member_id AND table_name = '$folder'
        ";
        global $con;
        $retval = mysqli_query($con, $sql);
        $count = mysqli_num_rows($retval);
        if($count < 1){
            $sql = "
                INSERT INTO tables(plan_id, member_id, table_name)
                VALUES($plan_id, $member_id, '$folder')
            ";
            // echo $sql;
            global $con;
            $retval = mysqli_query($con, $sql);
            if($retval){
                header("location: ../../view.php");
            }
            else {
                echo "
                    <script>
                        const result = window.confirm('Your session has expired');
                        
                        if(result === true){
                            window.location.href = '../../view.php';
                            
                        }
                        else {
                            window.location.href = '../../view.php';
                        }
                    </script>
                ";
            }
        }
        else {
            echo "
                <script>
                    const result = window.confirm('You already have this table');
                    
                    if(result === true){
                        window.location.href = '../../view.php';
                        
                    }
                    else {
                        window.location.href = '../../view.php';
                    }
                </script>
            ";
        }
    }
    else if(isset($_POST['table']) && isset($_POST['array']) && isset($_POST['command'])){
        $table = $_POST['table'];
        $array = $_POST['array'];
        $command = $_POST['command'];
        if($command == "add"){
            $currentTimestamp = mktime(0, 0, 0, $array[1], $array[2], $array[0]);
            $date = date("Y-m-d H:i:s", $currentTimestamp);

            $category_id = find_category_id($array[10], $table);
            $sql = "";
            if($table == "crj" || $table == "cpj"){
                $sql = "
                    INSERT INTO `$table`(`member_id`, `plan_id`, `date`, `details`, `folio_number`, `amount`, `column_1`, `column_2`, `diverse_amount`, `diverse_detail`, `category_id`) 
                    VALUES ({$_SESSION['member_id']}, {$_SESSION['plan_id']}, '$date', '{$array[3]}', '{$array[4]}', '{$array[5]}', '{$array[6]}', '{$array[7]}', '{$array[8]}', '{$array[9]}', 0$category_id)
                ";
            }
            else if($table == "arj" || $table == "apj"){
                $sql = "
                    INSERT INTO `$table`(`member_id`, `plan_id`, `date`, `details`, `folio_number`, `amount`, `category_id`) 
                    VALUES ({$_SESSION['member_id']}, {$_SESSION['plan_id']}, '$date', '{$array[3]}', '{$array[4]}', '{$array[5]}', 0$category_id)
                ";
            }
            
            global $con;
            $retval = mysqli_query($con, $sql);
            if($retval){
                echo "True";
            }
            else {
                echo $sql;
            }
        }
        else if($command == "edit"){
            $currentTimestamp = mktime(0, 0, 0, $array[1], $array[2], $array[0]);
            $date = date("Y-m-d H:i:s", $currentTimestamp);
            
            if($table == "crj" || $table == "cpj"){
                $sql = "
                    UPDATE $table
                    SET date = '$date', details = '{$array[3]}', folio_number = '{$array[4]}', amount = {$array[5]}, column_1 = {$array[6]}, column_2 = {$array[7]}, diverse_amount = {$array[8]}, diverse_detail = '{$array[9]}'
                    WHERE member_id = {$_SESSION['member_id']} AND plan_id = {$_SESSION['plan_id']} AND id = {$array[10]}
                ";
            }
            else if($table == "arj" || $table == "apj"){
                $sql = "
                    UPDATE $table
                    SET date = '$date', details = '{$array[3]}', folio_number = '{$array[4]}', amount = {$array[5]}
                    WHERE member_id = {$_SESSION['member_id']} AND plan_id = {$_SESSION['plan_id']} AND id = {$array[10]}
                ";
            }
            

            global $con;
            $retval = mysqli_query($con, $sql);
            if($retval){
                echo "True";
            }
            else {
                echo $sql;
            }
        }
        else if($command == "delete"){
            $menu = $_SESSION['menu'];
            $sql = "
                DELETE FROM $menu
                WHERE member_id = {$_SESSION['member_id']} AND plan_id = {$_SESSION['plan_id']} AND id = {$array[0]}
            ";

            global $con;
            $retval = mysqli_query($con, $sql);
            if($retval){
                echo "True";
            }
            else {
                echo $sql;
            }
        }
    }
    
    function find_category_id($category, $table){
        $sql = "
            SELECT category_id
            FROM categories
            WHERE member_id = {$_SESSION['member_id']} AND plan_id = {$_SESSION['plan_id']} AND category = $category AND table_name = '$table'
        ";
        global $con;
        $retval = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($retval, MYSQLI_ASSOC);
        return 0 . $row['category_id'];
    }
?>