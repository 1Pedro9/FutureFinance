<?php

    require("../../config.php");

    $id = $_POST['id'];
    $table = $_POST['table'];
    $time = $_POST['time'];

    $sql = "
        SELECT *
        FROM $table
        WHERE id = $id
    ";
    global $con;
    $retval = mysqli_query($con, $sql);

    while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)){
        echo '
            <input type="text" class="category" value="" hidden>
            <th class="action"><button class="add"><span class="material-symbols-outlined">add</span></button></th>
            <th class="year"><input type="text" value="' . $time[0] . '"></th>
            <th class="month"><input type="text" value="' . $time[1] . '"></th>
            <th class="day"><input type="text" value="' . $time[2] . '"></th>
            <th class="details"><input type="text" value="' . $row['details'] . '" placeholder="Add Details"></th>
            <th class="fol"><input type="text" value="' . $row['folio_number'] . '"></th>
            <th class="amount"><input type="text" value="' . $row['amount'] . '"></th>
            <th class="column-1"><input type="text" value="' . $row['column-1'] . '"></th>
            <th class="column-2"><input type="text" value="' . $row['column-2'] . '"></th>
            <th class="diverse-amount"><input type="text" value="' . $row['diverse-amount'] . '"></th>
            <th class="diverse-details"><input type="text" value="' . $row['diverse-details'] . '"></th>
        ';
    }


?>