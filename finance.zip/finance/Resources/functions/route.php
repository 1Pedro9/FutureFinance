<?php
    require("../../config.php");
    require("../../function.php");
    session_start();

    if(isset($_GET['plan'])){
        $plan = $_GET['plan'];
        $_SESSION['plan_id'] = $plan;
        header("location: ../../view.php");
    }
    else if(isset($_GET['planname'])){
        $plan = $_GET['planname'];

        $sql = "
            SELECT *
            FROM plans 
            WHERE plan = '$plan' AND member_id = {$_SESSION['member_id']}
        ";
        global $con;
        $retval = mysqli_query($con, $sql);
        $count = mysqli_num_rows($retval);
        
        if($count < 1){
            $sql = "
                INSERT INTO plans (`member_id`, `plan`)
                VALUES ({$_SESSION['member_id']}, '$plan')
            ";
            global $con;
            $retval = mysqli_query($con, $sql);
            if($retval){
                $sql = "SELECT plan_id FROM plans WHERE plan = '$plan' AND member_id = {$_SESSION['member_id']}";
                global $con;
                $retval = mysqli_query($con, $sql);
                $plan_id = mysqli_fetch_array($retval, MYSQLI_ASSOC);
                $_SESSION['plan_id'] = $plan_id['plan_id'];
                header("location: ../../view.php");
            }
            else {
                echo "
                    <script>
                        const result = window.confirm('There was a problem with the input you have given or your session has run out');
                        
                        if(result === true){
                            window.location.href = '../../index.php';
                            
                        }
                        else {
                            window.location.href = '../../index.php';
                        }
                    </script>
                ";
            }
        }
        else {
            echo "
                <script>
                    const result = window.confirm('You already have a statement with this name');
                    
                    if(result === true){
                        window.location.href = '../../index.php';
                        
                    }
                    else {
                        window.location.href = '../../index.php';
                    }
                </script>
            ";
        }
    }
    else if(isset($_GET['removename'])){
        $plan = $_GET['removename'];
        $member_id = $_SESSION['member_id'];
        
        backup($plan);
        
        $sql = "
            DELETE FROM plans
            WHERE member_id = {$member_id} AND plan = '$plan'
        ";
        global $con;
        $retval = mysqli_query($con, $sql);
        if($retval){
            echo "
                <script>
                    const result = window.confirm('You successfully deleted: $plan');
                    
                    if(result === true){
                        window.location.href = '../../index.php';
                        
                    }
                    else {
                        window.location.href = '../../index.php';
                    }
                </script>
            ";
        }
        else {
            echo "
                <script>
                    const result = window.confirm('Your session has expired');
                    
                    if(result === true){
                        window.location.href = '../../index.php';
                        
                    }
                    else {
                        window.location.href = '../../index.php';
                    }
                </script>
            ";
        }
    }
    else if(isset($_GET['logout'])){
        session_destroy();
        header("location: ../../view.php");
    }
    
    function backup($plan_name){
        
        $member_id = $_SESSION['member_id'];
        $sql = "
            SELECT plan_id
            FROM plans
            WHERE plan = '$plan_name' AND member_id = $member_id
        ";
        global $con;
        $retval = mysqli_query($con, $sql);
        $plan = mysqli_fetch_array($retval, MYSQLI_ASSOC)['plan_id'];
        
        $filePath = "../txt/{$member_id}_{$plan_name}_{$plan}.csv";
        $string = "";
        
        $crj = help_backup($plan, "crj");
        $string .= "CRJ:Cash Received Journal\n";
        $string .= "Date,Details,FOL,Amount,Column-1,Column-2,Diverse Amount,Diverse Details\n";
        forEach($crj as $object){
            $string .= "{$object['date']},{$object['details']},{$object['folio_number']},{$object['amount']},{$object['column_1']},{$object['column_2']},{$object['diverse_amount']},{$object['diverse_detail']}\n";
        }
        $cpj = help_backup($plan, "cpj");
        $string .= "\nCPJ:Cash Paid Journal\n";
        $string .= "Date,Details,FOL,Bank,Current Income,Accounts Received,Amount,Diverse Details\n";
        forEach($cpj as $object){
            $string .= "{$object['date']},{$object['details']},{$object['folio_number']},{$object['amount']},{$object['column_1']},{$object['column_2']},{$object['diverse_amount']},{$object['diverse_detail']}\n";
        }
        
        $arj = help_backup($plan, "arj");
        $string .= "\nARJ:Accounts Received Journal\n";
        $string .= "Date,FOL,Amount\n";
        forEach($arj as $object){
            $string .= "{$object['date']},{$object['folio_number']},{$object['amount']}\n";
        }
        
        $ar = help_backup($plan, "ar");
        $string .= "FOL,Details\n";
        $string .= "\nAR:Accounts Received\n";
        forEach($ar as $object){
            $string .= "{$object['folio_number']},{$object['details']}\n";
        }
        
        $file = fopen($filePath, 'w');
        
        if($file){
            fwrite($file, $string);
            fclose($file);
        }
    }
    
    function help_backup($plan, $table){
        $member_id = $_SESSION['member_id'];
        
        $sql = "
            SELECT *
            FROM $table
            WHERE plan_id = $plan AND member_id = $member_id
        ";
        $array = array();
        global $con;
        $retval = mysqli_query($con, $sql);
        
        while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)){
            $array[] = $row;
        }
        
        return $array;
    }
?>