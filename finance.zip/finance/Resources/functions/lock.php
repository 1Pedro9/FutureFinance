<?php
    
    session_start();
    echo $_SESSION['lock_plan'];
    if ($_SESSION['lock_plan'] == "locked"){
        $_SESSION['lock_plan'] = "open";
    }
    else{
        $_SESSION['lock_plan'] = "locked";
    }
    echo $_SESSION['lock_plan'];
    header("location:../../view.php");
    
?>