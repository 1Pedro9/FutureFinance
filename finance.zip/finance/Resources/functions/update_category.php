<?php
    
    session_start();
    require("../../config.php");
    if(isset($_POST['category']) && isset($_POST['color'])){
        $category = $_POST['category'];
        $color = $_POST['color'];
        $member_id = $_SESSION['member_id'];
        $plan_id = $_SESSION['plan_id'];
        $menu = $_SESSION['menu'];
        $sql = "
            UPDATE categories
            SET color = '$color'
            WHERE category = '$category' 
            AND member_id = $member_id
            AND plan_id = $plan_id
            AND table_name = '$menu'
        ";
        global $con;
        $retval = mysqli_query($con, $sql);
        if($retval){
            echo "Success";
        }
        else {
            echo "$sql";
        }
    }
    else if(isset($_POST['id']) && isset($_POST['update'])){
        $id = $_POST['id'];
        $category = $_POST['update'];
        $member_id = $_SESSION['member_id'];
        $plan_id = $_SESSION['plan_id'];
        $menu = $_SESSION['menu'];
        $sql = "
            SELECT category_id
            FROM categories
            WHERE category = '$category' 
            AND member_id = $member_id
            AND plan_id = $plan_id
        ";
        global $con;
        $retval = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($retval, MYSQLI_ASSOC);
        $category_id = $row['category_id'];
        
        $sql = "
            UPDATE $menu
            SET category_id = '$category_id'
            WHERE id = '$id' 
            AND member_id = $member_id
            AND plan_id = $plan_id
        ";
        global $con;
        $retval = mysqli_query($con, $sql);
        if($retval){
            echo "Success";
        }
        else {
            echo "$sql";
        }
    }
    if(isset($_GET['add'])){
        $category = $_GET['add'];
        $member_id = $_SESSION['member_id'];
        $plan_id = $_SESSION['plan_id'];
        $menu = $_SESSION['menu'];
        
        $sql = "
            SELECT *
            FROM categories
            WHERE category = '$category' 
            AND member_id = $member_id
            AND plan_id = $plan_id
            AND table_name = '$menu'
        ";
        global $con;
        $retval = mysqli_query($con, $sql);
        $count = mysqli_num_rows($retval);
        if($count < 1){
            $sql = "
                INSERT INTO categories (category, member_id, plan_id, table_name)
                VALUES('$category', $member_id, $plan_id, '$menu')
            ";
            global $con;
            $retval = mysqli_query($con, $sql);
            
            if($retval){
                echo "
                    <script>
                        const result = window.confirm('You successfully added a category');
                        
                        if(result === true){
                            window.location.href = '../../view.php';
                            
                        }
                        else {
                            window.location.href = '../../view.php';
                        }
                    </script>
                ";
            }
            else {
                echo "
                    <script>
                        const result = window.confirm('Your session has expired');
                        
                        if(result === true){
                            window.location.href = '../../view.php';
                            
                        }
                        else {
                            window.location.href = '../../view.php';
                        }
                    </script>
                ";
            }
        }
        else {
            echo "
                <script>
                    const result = window.confirm('You already have this category');
                    
                    if(result === true){
                        window.location.href = '../../view.php';
                        
                    }
                    else {
                        window.location.href = '../../view.php';
                    }
                </script>
            ";
        }
        
    }
    if(isset($_GET['clear'])){
        $id = $_GET['clear'];
        $table = $_SESSION['menu'];
        $plan = $_SESSION['plan_id'];
        $member = $_SESSION['member_id'];
        
        $sql = "
            UPDATE $table
            SET category_id = 0
            WHERE member_id = $member AND plan_id = $plan AND id = $id
        ";
        global $con;
        $retval = mysqli_query($con, $sql);
        
        if($retval){
            echo "
                <script>
                    const result = window.confirm('You successfully cleared a category');
                    
                    if(result === true){
                        window.location.href = '../../view.php';
                        
                    }
                    else {
                        window.location.href = '../../view.php';
                    }
                </script>
            ";
        }
        else {
            echo "
                <script>
                    const result = window.confirm('Your session has expired');
                    
                    if(result === true){
                        window.location.href = '../../view.php';
                        
                    }
                    else {
                        window.location.href = '../../view.php';
                    }
                </script>
            ";
        }
    }
    
?>