<?php
    session_start();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['menu'])) {
            $_SESSION['menu'] = $_POST['menu'];
            echo "Session menu set successfully";
        } else {
            echo "Menu value not provided";
        }
    } else {
        echo "Invalid request method";
    }
?>
