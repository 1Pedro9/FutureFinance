<?php
    
    session_start();
    require("../../config.php");
    
    if(isset($_POST['command'])){
        $command = $_POST['command'];
        $array = $_POST['array'];
        $table = $_SESSION['menu'];
        $member = $_SESSION['member_id'];
        $plan = $_SESSION['plan_id'];
        
        if($command == "update"){
            $column = str_replace("-", "_", $array[0]);
            
            $sql = "
                UPDATE columns
                SET $column = '{$array[1]}'
                WHERE member_id = $member AND plan_id = $plan
                AND table_name = $table
            ";
            
            global $con;
            $retval = mysqli_query($con, $sql);
            if($retval){
                echo "Success";
            }
            else {
                echo $sql;
            }
        }
    }
    
?>