<?php
    require ("../../config.php");
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
        $email= mysqli_real_escape_string($con, $_POST['email']);
        $fname = mysqli_real_escape_string($con, $_POST['fname']);
        $lname = mysqli_real_escape_string($con, $_POST['lname']);
       // $pincode =$_POST['pincode'];
        $password = md5(mysqli_real_escape_string($con, $_POST['password']));
    
        $sql = "SELECT email FROM user WHERE email = '$email'";
        $retval=mysqli_query($con,$sql);
        $row = mysqli_fetch_array($retval,MYSQLI_ASSOC);
        $count = mysqli_num_rows($retval);
    
        if($count >= 1){
            header("location:unsuccess-page.php?message=Your email already exists");
        }
        else {
            $sql="
                INSERT INTO `members`(`member_id`, `email`, `time_joined`, `password`, `first_name`, `last_name`, `age`, `is_married`, `has_children`, `amount_of_children`, `is_male`, `country`, `employment_status`, `job_roll`, `job_level`, `company_size`, `industry`, `household_income`, `is_admin`) 
                VALUES (null,'$email',now(),$password,'$fname','lname','','','','','','','','','','','','','')
            ";
             //  $sql = "INSERT INTO `user`(`email`, `fname`, `lname`,`isadmin`) VALUES ('$email','$fname','$lname','$password',0)";
            // $retval = mysqli_query($con, $sql);
            echo $sql;
            if($retval){
                mysqli_commit($con);
                session_start();
                
                
                $_SESSION['email'] = $email;
                $_SESSION['password'] = $password;
                $_SESSION['firstname'] = $fname;
                $_SESSION['lastname'] = $lname;
        
                header("location: ../../index.php");
            }
            else {
                echo $sql;
                // header("location: unsuccess-page.php");
            }
            
        }
    }
    else{
        header("location:unsuccessPage.php?message=There was a problem with the server");
    }
?>