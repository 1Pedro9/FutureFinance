<?php
    // require("../../config.php");
    session_start();
    
    class Test {
        public function __construct(){
            
        }
        public function test(){
            echo "why";
        }
    }
    
    class Journal {
        private $id;
        private $table;
        private $member_id;
        private $plan_id;
        private $date;
        private $details;
        private $fol;
        private $amount;
        private $column_1;
        private $column_2;
        private $da;
        private $dd;
        private $category_id;
        private $category;
        private $color;

        public function __construct($id, $table) {
            $this->id = $id;
            $this->table = $table;
            $this->set_variables();
            $this->set_categories();
        }

        private function set_variables(){
            $table = $this->table;
            $member_id = $_SESSION['member_id'];
            $plan_id = $_SESSION['plan_id'];
            $id = $this->id;
            $sql = "
                SELECT * 
                FROM $table 
                WHERE member_id = $member_id AND plan_id = $plan_id AND id = $id
            ";
            global $con;
            $retval = mysqli_query($con, $sql);
            while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)){
                $this->member_id = $_SESSION['member_id'];
                $this->plan_id = $_SESSION['plan_id'];
                $this->date = $row['date'];
                $this->details = $row['details'];
                $this->amount = $row['amount'];
                $this->column_1 = $row['column_1'];
                $this->column_2 = $row['column_2'];
                $this->da = $row['diverse_amount'];
                $this->dd = $row['diverse_detail'];
                $this->category_id = $row['category_id'];
            }
        }

        public function getID(){
            return $this->id;
        }
        public function getTable(){
            return $this->table;
        }
        public function getDate(){
            return $this->date;
        }
        public function getYear(){
            return date("Y", strtotime($this->date));
        }
        public function getMonth(){
            return date("m", strtotime($this->date));
        }
        public function getDay(){
            return date("d", strtotime($this->date));
        }
        public function getDetails(){
            return $this->details;
        }
        public function getFOL(){
            return $this->fol;
        }
        public function getAmount(){
            return $this->amount;
        }
        public function getColumn_1(){
            return $this->column_1;
        }
        public function getColumn_2(){
            return $this->column_2;
        }
        public function getDiverseAmount(){
            return $this->da;
        }
        public function getDiverseDetails(){
            return $this->dd;
        }
        public function getCategoryID(){
            return $this->category_id;
        }
        public function set_categories(){
            $sql = "
                SELECT *
                FROM categories
                WHERE member_id = {$this->member_id}
                AND plan_id = {$this->plan_id}
                AND table_name = '{$this->table}'
                AND category_id = {$this->category_id}
            ";
            global $con;
            $retval = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($retval, MYSQLI_ASSOC);
            $this->category = $row['category'];
            $this->color = $row['color'];
        }
        public function getCategory(){
            return $this->category;
        }
        public function getColor(){
            return $this->color;
        }
    }
    
    class GL{
        private $year;
        private $month;
        private $amount;
        private $table;

        public function __construct($year, $month, $amount, $table){
            $this->year = $year;
            $this->month = $month;
            $this->amount = $amount;
            $this->table = $table;
        }

        public function getYear(){
            return $this->year;
        }

        public function getMonth(){
            return $this->month;
        }

        public function getAmount(){
            return $this->amount;
        }

        public function getTable(){
            return $this->table;
        }

    }

?>