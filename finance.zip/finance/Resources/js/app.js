
function show_journals(object){
    const journals = object.parentElement.querySelector(".journals");
    journals.hidden = !journals.hidden;
}

function toggleSidebar() {
    const sidebar = document.querySelector("#sidebar");
    sidebar.style.width = sidebar.style.width === "300px" ? "0" : "300px";
}
function closeSidebar() {
    const sidebar = document.querySelector("#ease-sidebar");
    sidebar.style.width = "0";
}

function toggleEaseSidebar() {
    const sidebar = document.querySelector("#ease-sidebar");
    sidebar.style.width = sidebar.style.width === "300px" ? "0" : "300px";
    update_entries_container();
}

function update_entries_container(){
    document.querySelectorAll(".main-rows").forEach(row => {
        const amount = row.querySelector(".amount");
        const cat = row.querySelector(".category");
        if(amount.classList.contains("chosen-row")){
            if(cat.value != ""){
                document.querySelector(".entries-container").hidden = true;
            }
            else {
                document.querySelector(".entries-container").hidden = false;
            }
        }
    });
}

let yStart = 0;
function canvas(){
    const canvas = document.getElementById("bank_status");
    const ctx = canvas.getContext("2d");

    const screenWidth = 300;
    

    const income = parseInt(document.querySelector("#income").textContent, 10);
    const expenses = parseInt(document.querySelector("#expenses").textContent, 10);

    if(income != null || expenses != null){
        if(income >= expenses){
            const diff = expenses/income;    
            drawRectangle(screenWidth, "#00BF63", ctx);
            drawRectangle((screenWidth*diff), "#FF5757", ctx);
        }
        else if(income < expenses) {
            const diff = income/expenses;    
            drawRectangle((screenWidth*diff), "#00BF63", ctx);
            drawRectangle(screenWidth, "#FF5757", ctx);
        }
        else {   
            drawRectangle((screenWidth), "#00BF63", ctx);
            drawRectangle(screenWidth, "#FF5757", ctx);
        }
    }
    else {
        drawRectangle(10, "#00BF63", ctx);
        drawRectangle(10, "#FF5757", ctx);
    }
    
}

function drawRectangle(cash, color, ctx) {
    const x = 0;
    const y = yStart;
    const width = cash;
    const height = 50;

    ctx.fillStyle = color;
    ctx.fillRect(x, y, width, height);
    yStart += 75;
}

function add_statement(e){
    const input = e.parentElement.querySelector("input");
    window.location.href = "Resources/functions/route.php?planname=" + input.value;
}

function remove_statement(e){
    const input = e.parentElement.querySelector("a");
    window.location.href = "Resources/functions/route.php?removename=" + input.textContent;
}

function route(e){
    window.location.href = e;
}


function keyboard_Shortcuts(){
    window.addEventListener("DOMContentLoaded", function(){
        window.addEventListener("keydown", (e) => {
            if(e.ctrlKey && e.key === 'm'){
                const sidebar = document.querySelector("#ease-sidebar");
                sidebar.style.width = sidebar.style.width === "300px" ? "0" : "300px";
            }

            if(e.ctrlKey && e.key === "s"){
                console.log("Saved");
                e.preventDefault();
            }
        });
    });
}

function showTooltip(icon, tooltipText) {
    var tooltip = document.createElement('div');
    tooltip.className = 'tooltip';
    tooltip.innerHTML = tooltipText;

    document.body.appendChild(tooltip);

    var iconRect = icon.getBoundingClientRect();
    tooltip.style.top = (iconRect.bottom + 1) + 'px';
    tooltip.style.left = iconRect.right + 'px';

    var timeoutId = setTimeout(function() {
        tooltip.style.display = 'block';
    }, 700);

    icon.onmouseout = function() {
        clearTimeout(timeoutId);
        tooltip.style.display = 'none';
    };
}

function open_category_modal(){
    let modal_count = 0;
    document.querySelectorAll(".main-row").forEach(row => {
        const amount = row.querySelector(".amount");
        if(amount.classList.contains("chosen-row")){
            modal_count++;
            if(modal_count > 1){
                document.querySelector(".categories-modal").hidden = false;
                toggleEaseSidebar();
            }
        }
    });
    
}

function close_category_modal() {
    document.querySelector(".categories-modal").hidden = true;
}

function open_entries_modal(){
    document.querySelector(".entries-modal").hidden = false;
    toggleEaseSidebar();
}

function close_entries_modal() {
    document.querySelector(".entries-modal").hidden = true;
}

function add_finder(){
    const finder = document.querySelector(".finder");
    finder.classList.add("show-finder");
}

function remove_finder(){
    const finder = document.querySelector(".finder");
    finder.classList.remove("show-finder");
}

function set_menu(value){
    $(document).ready(function () {
        var menuValue = value;

        $.ajax({
            type: 'POST',
            url: 'Resources/functions/set_menu.php',
            data: {menu: menuValue},
            success: function (response) {
                console.log(response);
                window.location.reload();
            },
            error: function () {
                console.error("Error setting session menu");
            }
        });
    });
}

function create_folder(){
    const select = document.querySelector(".folder-container select");
    if(select.value != ""){
        window.location.href = "Resources/functions/execute.php?add-folder=" + select.value;
    }
}

function open_folder(){
    const folder = document.querySelector(".add-folder");
    folder.classList.add("show-folder");
}

function cancel_folder(){
    const folder = document.querySelector(".add-folder");
    folder.classList.remove("show-folder");
}

function open_columns(e){
    const folder = document.querySelector(".change_name");
    document.querySelector("#column_chosen").input = e.classList[0];
    folder.classList.add("show-columns");
    window.alert(e.classList[0]);
}

function save_columns(){
    const chosen = document.querySelector("#column_chosen");
    const change = document.querySelector("#column_change");
    
    $(document).ready(function() {
        command = "update";
        var array = [chosen, change];
        $.ajax({
            url: 'Resources/functions/update_column.php',
            type: 'POST',
            dataType: 'text',
            data: { table: table, array: array, command: command },
            success: function(response) {
                console.log(response);
                if(response == "Success"){
                    window.location.reload();
                }
                else {
                    window.alert(response);
                } 
            },
            error: function(xhr, status, error) {
                console.log('Error:', error);
            }
        });
        // });
    });
    cancel_columns();
}

function cancel_columns(){
    const folder = document.querySelector(".change_name");
    folder.classList.remove("show-columns");
}

function logout(){
    window.location.href = "Resources/functions/route.php?logout=true";
}

function toggle_info_container(e){
    const folder = document.querySelector(".big-info");
    folder.classList.toggle("show-big-info");
    e.textContent = e.textContent === "expand_more" ? "expand_less" : "expand_more";
}