/* 
Imports
 * <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
*/
const init_width = [0, 40, 50, 30, 150, 30, 120, 120, 120, 120, 250];
const gl_width = [40, 50, 30, 150, 40, 120, 40, 50, 30, 150, 40, 120];
const arl_width = [40, 50, 30, 150, 30, 120, 120, 120];
let selected_row = null;
let is_shifted = false;
let finder_counter = 1;
let finder_amount = 0;
let shift_amount = 0;


assign_widths();
function assign_widths(){
    const containers = document.querySelectorAll("tr");
    containers.forEach((element) => {
        const tr_input = element.querySelectorAll("th input");
        // console.log(element);
        tr_input.forEach((object, i) => {
            let string = "";
            if(get_table() == "gl"){
                string = gl_width[i] + "px";
            }
            else if(get_table() == "arl" || get_table() == "apl"){
                string = arl_width[i] + "px";
            }
            else if(get_table() == "ar" || get_table() == "ap"){
                string = "350px";
            }
            else {
                string = init_width[i] + "px";
            }
            object.style.width = string;
        });
    });
}

choose_row();
function choose_row(){
    const containers = document.querySelectorAll(".main-rows");
    containers.forEach((element) => {
        element.addEventListener("click", function(){
            if(shift_amount > 1 && !is_shifted){
                shift_amount = 0;
                sidebar_id(null, "Clear");
                document.querySelectorAll("th").forEach((object) => {
                    object.classList.remove("chosen-row");
                });
            }
            if(!is_shifted){
                document.querySelectorAll(".target").forEach(element2 => {
                    element2.querySelectorAll("th").forEach(object => {
                        object.classList.remove("chosen-row");
                    });
                });
            }
            else {
                shift_amount++;
            }
            element.querySelectorAll("th").forEach(object => {
                
                element.querySelector(".action").style.background = "transparent";
                object.classList.add("chosen-row");
                update_category_chosen();
                update_entries_container();
            });
            selected_row = element;
            document.querySelectorAll(".add-rows").forEach(element2 => {
                element2.addEventListener("click", function(){
                    is_shifted = false;
                    shift_amount = 0;
                    document.querySelectorAll(".target").forEach(element2 => {
                        element2.querySelectorAll("th").forEach(object => {
                            object.classList.remove("chosen-row");
                            element.querySelector(".action").style.background = "transparent";
                        });
                    });
                });
            });
            if(shift_amount < 2 || !is_shifted){
                sidebar_id(selected_row, "Single");
            }
            else if(shift_amount > 0 && is_shifted) {
                sidebar_id(selected_row, "Shift");
            }
        });
    });
}

function sidebar_id(row, command){
    const a = document.querySelector("#ease-sidebar-id-h4");
    let id = null;
    if(row != null){
        id = row.id;
    }
    
    if(command == "Shift"){
        if(shift_amount < 2){
            a.textContent += "Row " + id;
        }
        else {
            a.textContent += ", Row " + id;
        }
    }
    else if(command == "Clear"){
        a.textContent = "";
        clear_info_container();
    }
    else if(command == "Single"){
        a.textContent = "Row " + id;
        update_info_container(row);
    }
    else {

    }
    
}

edit();
function edit() {
    const action = document.querySelectorAll(".action button");
    action.forEach((button) => {
        const span = button.querySelector("span");
        if(span.textContent == "edit"){
            button.addEventListener("click", function(){

            });
        }
        else if(span.textContent == "delete"){
            button.style.display = "none";
        }
        else if(span.textContent == "add"){
            button.addEventListener("click", function(){
                add_rows(button);
            });
        }
    });
}

function command(table, array, command){
    $(document).ready(function() {
        $.ajax({
            url: 'Resources/functions/execute.php',
            type: 'POST',
            dataType: 'text',
            data: { table: table, array: array, command: command },
            success: function(response) {
                console.log(response);
                if(response == "True"){
                    window.location.reload();
                    return true;
                }
                else {
                    return false;
                } 
            },
            error: function(xhr, status, error) {
                console.log('Error:', error);
            }
        });
        // });
    });
}

function add_rows(button){
    const container = button.parentElement.parentElement;
    const table = container.parentElement.parentElement.parentElement.id;

    let array = [];
    
    let list = [];
    if(table == "crj" || table == "cpj"){
        list = ["year", "month", "day", "details", "fol", "amount", "column-1", "column-2", "diverse-amount", "diverse-details"];
    }
    else if(table == "arj" || table == "apj") {
        list = ["year", "month", "day", "details", "fol", "amount"];
    }
    
    for(var i = 0; i < list.length; i++){
        const element = container.querySelector("." + list[i] + " input").value;
        array.push(element);
    }
    const element = container.querySelector(".category").value;
    array.push(element);

    
    if(table == "crj" || table == "cpj"){
        const validation = validation_checks(container, table, array, list);
        if(validation){
            if(command(table, array, "add")){
                window.location.reload();
            }
            else {
    
            }
        }
    }
    else {
        if(command(table, array, "add")){
            window.location.reload();
        }
        else {

        }
    }
    
}

function edit_rows(button){
    const container = button.parentElement.parentElement;
    const table = container.parentElement.parentElement.parentElement.id;

    let array = [];
    
    let list = [];
    if(table == "crj" || table == "cpj"){
        list = ["year", "month", "day", "details", "fol", "amount", "column-1", "column-2", "diverse-amount", "diverse-details"];
    }
    else if(table == "arj" || table == "apj") {
        list = ["year", "month", "day", "details", "fol", "amount"];
    }
    
    for(var i = 0; i < list.length; i++){
        const element = container.querySelector("." + list[i] + " input").value;
        array.push(element);
    }
    array.push(container.id);
    
    if(table == "crj" || table == "cpj"){
        const validation = validation_checks(container, table, array, list);
        if(validation){
            if(command(table, array, "edit")){
                window.location.reload();
            }
            else {
    
            }
        }
    }
    else {
        if(command(table, array, "edit")){
            window.location.reload();
        }
        else {

        }
    }
}

function validation_checks(row, table, array, list){
    let command = true;

    if(sum_check(array)){
        row.querySelector(".amount").classList.remove("highlight-wrong");
        row.querySelector(".column-1").classList.remove("highlight-wrong");
        row.querySelector(".column-2").classList.remove("highlight-wrong");
        row.querySelector(".diverse-amount").classList.remove("highlight-wrong");
        command = true;
    }
    else {
        highlight_wrong(row.querySelector(".amount"));
        highlight_wrong(row.querySelector(".column-1"));
        highlight_wrong(row.querySelector(".column-2"));
        highlight_wrong(row.querySelector(".diverse-amount"));
        command = false;
    }

    let is_present = true;
    let length = 0;
    if(array.length > 9){
        length = array.length - 1;
    }
    else {
        length = array.length;
    }
    for (let i = 0; i < length; i++) {
        const element = array[i];
        
        if(!present_check(element) && list[i] != "fol"  && list[i] != "diverse-details"){
            highlight_wrong(row.querySelector("." + list[i] + ""))
            is_present = false;
        }
        else {
            row.querySelector("." + list[i] + "").classList.remove("highlight-wrong");
        }
    }
    if(command){
        command = is_present;
    }

    if(together_check(row)){
        row.querySelector(".diverse-details").classList.remove("highlight-wrong");
        row.querySelector(".diverse-amount").classList.remove("highlight-wrong");
    }
    else {
        highlight_wrong(row.querySelector(".diverse-details"));
        highlight_wrong(row.querySelector(".diverse-amount"));
        command = false;
    }

    return command;
}

function sum_check(array){
    const bank = parseFloat(array[5]);
    const col1 = parseFloat(array[6]);
    const col2 = parseFloat(array[7]);
    const div = parseFloat(array[8]);

    const sum = col1 + col2 + div;
    if(bank == (sum)){
        return true;
    }
    else {
        return false;
    }
}

function present_check(element){
    if(element == ""){
        return false;
    }
    else {
        return true;
    }
}

function together_check(row){
    const amount = row.querySelector(".diverse-amount input").value;
    const details = row.querySelector(".diverse-details input").value;

    if(parseFloat(amount) > 0){
        if(details != ""){
            return true;
        }
        else {
            return false;
        }
    }
    else if (parseFloat(amount) == 0) {
        return true;
    }
    else {
        return false;
    }
}

function highlight_wrong(row){
    row.classList.add("highlight-wrong");
    setTimeout(function(){
        row.classList.remove("highlight-wrong");
    }, 250);
    setTimeout(function(){
        row.classList.add("highlight-wrong");
    }, 500);
}

drag_and_drop();

function drag_and_drop(){
    const table = document.querySelector("table").parentElement.id;
    let list = null;

    if(table == "crj" || table == "cpj"){
        list = ["details", "fol", "amount", "column-1", "column-2", "diverse-amount", "diverse-details"];
    }
    else if(table == "arj" || table == "apj"){
        list = ["details", "fol", "amount"];
    }
    
    document.querySelectorAll(".main-rows .action .edit span").forEach((icon, i) => {
        let is_dragging = false;
        const main = icon.parentElement.parentElement.parentElement;

        
        icon.addEventListener("mousedown", (e) => {
            is_dragging = true;
        });

        document.querySelectorAll(".add-rows .action .add span").forEach((add, j) => {
            add.addEventListener("mouseup", () => {
                if(is_dragging){
                    const add_row = add.parentElement.parentElement.parentElement;
                    list.forEach(element => {
                        replace_inputs(main, add_row, element);
                    });
                    replace_category(main, add_row, "category")
                }
                is_dragging = false;
            });
        });

        document.addEventListener("mouseup", function(){
            is_dragging = false;
        });
    });
}

function replace_inputs(main, add, query){
    const obj1 = main.querySelector("." + query + " input");
    const obj2 = add.querySelector("." + query + " input");

    if(obj1.value != 0 || obj1.value != ""){
        obj2.value = obj1.value;
    }
}
function replace_category(main, add, query){
    const obj1 = main.querySelector("." + query);
    const obj2 = add.querySelector("." + query);

    if(obj1.value != 0 || obj1.value != ""){
        obj2.value = obj1.value;
    }
}

edit_change();
function edit_change(){
    document.querySelectorAll(".main-rows .action .edit span").forEach((object, i) => {
        object.addEventListener("click", function(){
            if(object.textContent == "edit"){
                object.textContent = "save";
                document.querySelectorAll(".main-rows .action .delete")[i].style.display = "block";
                const tr = object.parentElement.parentElement.parentElement;
                tr.querySelectorAll("input").forEach((input) => {
                    input.readOnly = false;
                });
            }
            else if(object.textContent == "save"){
                object.textContent = "edit";
                document.querySelectorAll(".main-rows .action .delete")[i].style.display = "none";
                const tr = object.parentElement.parentElement.parentElement;
                tr.querySelectorAll("th").forEach((th) => {
                    th.classList.remove("chosen-row");
                });
                edit_rows(object.parentElement);
                tr.querySelectorAll("input").forEach((input) => {
                    input.readOnly = true;
                });
            }
        }); 
    });
}

delete_change();
function delete_change(){
    document.querySelectorAll(".main-rows .action .delete span").forEach((object, i) => {
        object.addEventListener("click", function(){
            if(object.textContent == "delete"){
                let id = object.parentElement.parentElement.parentElement.id;
                const result = window.confirm('Do you want to delete this row');
                    
                if(result === true){
                    command(get_table(), [id], "delete");
                }
                else {
                    
                }
            }
        }); 
    }); 
}

assign_category();
function assign_category(){
    document.querySelectorAll(".categories-wrapper h4").forEach((category) => {
        category.addEventListener("click", function(){
            document.querySelectorAll(".main-rows").forEach((object, i) => {
                const amount = object.querySelector(".amount");
                const amount_input = amount.querySelector("input");
                if(amount.classList.contains("chosen-row")){
                    object.querySelector(".category").value = category.textContent;
                    amount_input.setAttribute("onmouseover", "showTooltip(this, '" + category.textContent + "')");
                    close_category_modal();
                    update_amount_color();                    //amount_input.style.color = get_category_color(category.textContent);
                
                    const id = object.id;
                    update_category_database(id, category.textContent)
                }
            });
        });
    });
}
function update_category_database(id, color){
    $(document).ready(function(){
        $.ajax({
            url: 'Resources/functions/update_category.php',
            type: 'POST',
            dataType: 'text',
            data: { id: id, update: color },
            success: function(response) {
                console.log(response);
            },
            error: function(xhr, status, error) {
                console.log('Error:', error);
            } 
        });
    });
}

function get_category_color(category){
    $(document).ready(function() {
        $.ajax({
            url: 'Resources/functions/get_color.php',
            type: 'POST',
            dataType: 'text',
            data: { category: category },
            success: function(response) {
                return response;
            },
            error: function(xhr, status, error) {
                console.log('Error:', error);
            }
        });
    });
}

chosen_add_row();
function chosen_add_row(){
    document.querySelectorAll(".add-rows").forEach(row => {
        
        row.addEventListener("click", function(){
            document.querySelectorAll(".add-rows").forEach(row2 => {
                if(row == row2){
                    row.classList.add("chosen_add");
                    update_category_chosen();
                }
                else {
                    row.classList.remove("chosen_add");
                }
            });
            auto_entry();
        })
    });
}

auto_entry();
function auto_entry(){
    document.querySelectorAll(".entries-wrapper h4").forEach((object) => {
        object.addEventListener("click", function(){
            const add_row = document.querySelector(".chosen_add");
            /*
            const array = object.textContent.split(" - R");
            let details = array[0];
            let amount = array[1];

            add_row.querySelector(".details input").value = details;
            add_row.querySelector(".amount input").value = amount;
            */
            const a = object.id;
            const id = a.split("-")[1];
            add_row.innerHTML = get_row(id);
            close_entries_modal();
        });
    });
}


function get_row(id){
    $(document).ready(function() {
        $.ajax({
            url: 'Resources/functions/get_row.php',
            type: 'POST',
            dataType: 'text',
            data: { id: id, table: get_table(), time: get_time() },
            success: function(response) {
                return response;
            },
            error: function(xhr, status, error) {
                console.log('Error:', error);
            }
        });
    });
}

function get_table(){
    const table = document.querySelector("main>div");
    const name = table.id;
    return name;
}

function get_time(){
    const row = document.querySelector(".chosen_add");
    let array = [
        row.querySelector(".year input").value,
        row.querySelector(".month input").value,
        row.querySelector(".day input").value
    ]
    return array;
}

update_amount_color();
function update_amount_color(){
    document.querySelectorAll(".main-rows").forEach((row) => {
        const category = row.querySelector(".category").value;
        const input = row.querySelector(".amount input");
        input.style.color = search_color(category);
    });
}

function search_color(category){
    let color = null;
    document.querySelectorAll(".list_all_categories h4").forEach((object) => {
        if(object.textContent == category){
            const button = object.parentElement.querySelector("input[type=\"color\"]");
            color = button.value;
        }
    });
    return color;
}

function update_category_color(e){
    update_amount_color();
    let category = e.parentElement.querySelector("h4").textContent;
    const color = e.value;;

    $(document).ready(function(){
        $.ajax({
            url: "Resources/functions/update_category.php",
            type: "POST",
            dataType: "text",
            data: {category: category, color: color},
            success: function(response){
                if(response == "Success"){
                    window.location.reload();
                    console.log("Add Category");
                }
                console.log(response);
               
            },
            error: function(xhr, status, error) {
                console.log('Error:', error);
            }
        })
    });
    
}


enter_shortcut();
function enter_shortcut(){
    document.querySelectorAll(".add-rows input").forEach((input) => {
        input.addEventListener("keyup", (e) => {
            if (e.key === "Enter") {
                if (document.activeElement === input) {
                    const button = input.parentElement.parentElement.querySelector(".action .add");
                    add_rows(button);
                }
            }
        });
        
    });

    document.querySelectorAll(".main-rows .edit span").forEach((span, i) => {
        span.addEventListener("click", function() {
            if(span.textContent === "save"){
                document.querySelectorAll(".main-rows input").forEach((input) => {
                    input.addEventListener("keyup", (e) => {
                        if (e.key === "Enter") {
                            if (document.activeElement === input) {
                                const button = input.parentElement.parentElement.querySelector(".action .edit");
                                document.querySelectorAll(".main-rows .action .delete")[i].style.display = "none";
                                span.textContent = "edit";
                                edit_rows(button);
                                input.parentElement.parentElement.querySelectorAll("input").forEach(a => {
                                    a.readOnly = true; 
                                });
                            }
                        }
                        else if(e.key === "Delete"){
                            if (document.activeElement === input){
                                var userConfirmed = window.confirm('Are you sure you want to delete?');

                                if (userConfirmed) {
                                    console.log("Delete Function Here");
                                } 
                                
                            }
                        }
                    });
                    
                });
            }
        });
        
    });

    window.addEventListener("DOMContentLoaded", function(){
        window.addEventListener("keydown", (e) => {
            if(e.key === "Escape"){
                is_shifted = false;
                shift_amount = 0;
                document.querySelectorAll("th").forEach((object) => {
                    object.classList.remove("chosen-row");
                });
                closeSidebar();
                remove_finder();
                close_finder_styles();
                sidebar_id(null, "Clear");
                update_category_chosen();
            }
            if(e.shiftKey){
                is_shifted = true;
            }
            if(e.ctrlKey && e.key === "f"){
                close_finder_styles();
                if(!is_shifted || shift_amount < 2){
                    const row = document.querySelector(".chosen-row").parentElement;
                    if(row){
                        e.preventDefault();
                        add_finder();
                        finder_amount = 0;
                        finder_counter = 0;
                        var finder_cont = true;
                        const category = row.querySelector(".category").value;
                        document.querySelector("#finder-input").value = category;
                        document.querySelectorAll(".main-rows").forEach((object) => {
                            const cat = object.querySelector(".category").value;
                            if(cat == category){
                                finder_amount++;
                                document.querySelector(".finder-left span").textContent = finder_counter + " of " + finder_amount;
                                object.querySelectorAll("th").forEach((th) => {
                                    if(!th.classList.contains("action")){
                                        th.classList.add("highlighted-row");
                                    }
                                });
                                if(row === object){
                                    finder_cont = false;
                                    finder_counter++;
                                    update_finder(finder_amount-1);
                                    document.querySelector(".finder-left span").textContent = (finder_counter) + " of " + finder_amount;
                                }
                                else if(row != object && finder_cont){
                                    finder_counter++;
                                }
                            }
                        });
                    }
                }
            }
        });
        window.addEventListener("keyup", (e) => {
            if(e.shiftKey || e.key === "Shift"){
                is_shifted = false;
                /*shift_amount = 0;
                sidebar_id(null, "Clear");
                document.querySelectorAll("th").forEach((object) => {
                    object.classList.remove("chosen-row");
                });*/
            }
        });
    });
}


function update_finder(n){
    document.querySelectorAll(".main-rows").forEach((row) => {
        const amount = row.querySelector(".amount");
        if(amount.classList.contains("chosen-highlighted-row")){
            row.querySelectorAll("th").forEach(th => {
                if(!th.classList.contains("action")){
                    th.classList.remove("chosen-highlighted-row");
                    th.classList.add("highlighted-row");
                }
            });
        }
    });
    let help = 0;
    document.querySelectorAll(".main-rows").forEach(main => {
        const amount = main.querySelector(".amount");
        if(amount.classList.contains("highlighted-row")){
            if(help == n){
                main.querySelectorAll("th").forEach(object => {
                    if(!object.classList.contains("action")){
                        object.classList.remove("highlighted-row");
                        object.classList.add("chosen-highlighted-row");
                        update_category_chosen();
                    }
                    
                });
                if (main) {
                    var windowHeight = window.innerHeight;
                    var targetOffset = main.getBoundingClientRect().top;
                    var scrollPosition = window.scrollY + targetOffset - (windowHeight / 2);

                    window.scrollTo({
                        top: scrollPosition,
                        behavior: 'smooth'
                    });
                }
            }
            help++;
        }
    });
    
}

function close_finder_styles(){
    document.querySelectorAll(".highlighted-row").forEach(object => {
        object.classList.remove("highlighted-row");
    });
    document.querySelectorAll(".chosen-highlighted-row").forEach(object => {
        object.classList.remove("chosen-highlighted-row");
    });
}

function finder_close_2(){
    remove_finder();
    close_finder_styles();
}

function increase_finder(){
    finder_counter++;
    if(finder_counter > finder_amount){
        finder_counter = 1;
    }
    else if(finder_counter < 1){
        finder_counter = finder_amount;
    }
    
    update_finder(finder_counter-1);
    document.querySelector(".finder-left span").textContent = finder_counter + " of " + finder_amount;
}
function decrease_finder(){
    finder_counter--;
    if(finder_counter > finder_amount){
        finder_counter = 1;
    }
    else if(finder_counter < 1){
        finder_counter = finder_amount;
    }
    
    update_finder(finder_counter-1);
    document.querySelector(".finder-left span").textContent = finder_counter + " of " + finder_amount;
}

function add_category(e){
    const input = e.parentElement.querySelector("input");
    if(input.value != ""){
        window.location.href = "Resources/functions/update_category.php?add=" + input.value;
    }
}

move_selected_row();
function move_selected_row(){
    let pos = -1;
    window.addEventListener("DOMContentLoaded", function(){
        window.addEventListener("keydown", (e) => {
            const length = document.querySelectorAll(".main-rows").length;
            document.querySelectorAll(".main-rows").forEach((object, i) => {
                const amount = object.querySelector(".amount");
                if(amount.classList.contains("chosen-row")){
                    pos = i;
                }
            });
            
            if(e.key === "ArrowUp"){
                let a = pos-1;
                if(a < 0){
                    a = length-1;
                }
                document.querySelectorAll(".main-rows")[pos].querySelectorAll("th").forEach(th => {
                    th.classList.remove("chosen-row") ;
                });
                document.querySelectorAll(".main-rows")[a].querySelectorAll("th").forEach(th => {
                    if(!th.classList.contains("action")){
                        th.classList.add("chosen-row");
                        update_category_chosen();
                    }
                });

            }else if(e.key === "ArrowDown"){
                let a = pos+1;
                if(a >= length){
                    a = 0;
                }
                document.querySelectorAll(".main-rows")[pos].querySelectorAll("th").forEach(th => {
                    th.classList.remove("chosen-row") ;
                });
                document.querySelectorAll(".main-rows")[a].querySelectorAll("th").forEach(th => {
                    if(!th.classList.contains("action")){
                        th.classList.add("chosen-row");
                        update_category_chosen();
                    }
                });
            }
            
            
        });
    })
}

function update_category_chosen(){
    document.querySelectorAll(".add-rows").forEach((object, i) => {
        const amount = object.querySelector(".amount");
        if(amount.classList.contains("chosen_add")){
            const category = object.querySelector(".category");
            document.querySelectorAll(".list-categories li").forEach((row) => {
                
                const h4 = row.querySelector("h4");
                if(category.value == h4.textContent){
                    row.classList.add("highlight-category-sidebar");
                }
                else {
                    row.classList.remove("highlight-category-sidebar");
                }
            });
        }
    });
}

copy_to_column();
function copy_to_column(){
    document.querySelectorAll(".add-rows").forEach(object => {
        object.addEventListener("click", function(){
            const row = document.querySelector(".chosen_add");
            if(row){
                const amount = row.querySelector(".amount input");
                amount.addEventListener("focus", function(){
                    amount.addEventListener("keydown", (e) => {
                        if(e.altKey && e.key === "1"){
                            if(row.querySelector(".column-1 input").value != amount.value){
                                row.querySelector(".column-1 input").value = amount.value;
                            }
                            else {
                                row.querySelector(".column-1 input").value = 0;
                            }
                            
                        }
                        else if(e.altKey && e.key === "2"){
                            if(row.querySelector(".column-2 input").value != amount.value){
                                row.querySelector(".column-2 input").value = amount.value;
                            }
                            else {
                                row.querySelector(".column-2 input").value = 0;
                            }
                        }
                        else if(e.altKey && e.key === "3"){
                            if(row.querySelector(".diverse-amount input").value != amount.value){
                                row.querySelector(".diverse-amount input").value = amount.value;
                            }
                            else {
                                row.querySelector(".diverse-amount input").value = 0;
                            }
                        }
                    });
                });
            }
        }) ;
    });
    document.querySelectorAll(".main-rows").forEach(object => {
        object.addEventListener("click", function(){
            const row = document.querySelector(".chosen-row");
            if(row){
                const amount = row.querySelector(".amount input");
                amount.addEventListener("focus", function(){
                    amount.addEventListener("keydown", (e) => {
                        if(e.altKey && e.key === "1"){
                            if(row.querySelector(".column-1 input").value != amount.value){
                                row.querySelector(".column-1 input").value = amount.value;
                            }
                            else {
                                row.querySelector(".column-1 input").value = 0;
                            }
                            
                        }
                        if(e.altKey && e.key === "2"){
                            if(row.querySelector(".column-2 input").value != amount.value){
                                row.querySelector(".column-2 input").value = amount.value;
                            }
                            else {
                                row.querySelector(".column-2 input").value = 0;
                            }
                        }
                        if(e.altKey && e.key === "3"){
                            if(row.querySelector(".diverse-amount input").value != amount.value){
                                row.querySelector(".diverse-amount input").value = amount.value;
                            }
                            else {
                                row.querySelector(".diverse-amount input").value = 0;
                            }
                        }
                    });
                });
            }
        }) ;
    });
    
}


function update_info_container(row){
    document.querySelector(".info-container").hidden = false;
    document.querySelector(".info-container h3").textContent = "Row: " + row.id;
    document.querySelector(".info-date span").textContent = row.querySelector(".year input").value + "/" + row.querySelector(".month input").value + "/" + row.querySelector(".day input").value;
    document.querySelector(".info-details span").textContent = row.querySelector(".details input").value;
    document.querySelector(".info-amount span").textContent = row.querySelector(".amount input").value;
    document.querySelector(".info-categories span").textContent = row.querySelector(".category").value;
}

function clear_info_container(){
    document.querySelector(".info-container").hidden = true;
}

function clear_category(){
    document.querySelectorAll(".main-rows").forEach(row => {
        const amount = row.querySelector(".amount") ;
        if(amount.classList.contains("chosen-row")){
            const input = row.id;
            if(input != ""){
                window.location.href = "Resources/functions/update_category.php?clear=" + input;
            }
        }
    });
}
