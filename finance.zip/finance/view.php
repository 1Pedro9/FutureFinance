<?php
    session_start();
    require("config.php");
    require("function.php");
    require("Resources/objects/financial_objects.php");

    if(auth_admin() || isset($_SESSION['member_id'])){
        if($_SESSION['lock_plan'] == "locked"){
            $is_locked = true;
        }
        else{
            $is_locked = false;
        }
    }
    else {
        header("location: Resources/php/login.html");
    }

    if(!isset($_SESSION['plan_id'])){
        header("location: index.php");
    }
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance - FTA</title>
    <link rel="stylesheet" href="Resources/css/styles.css"> 
    <link rel="stylesheet" href="Resources/css/navbar.css"> 
    <link rel="stylesheet" href="Resources/css/table.css">
    <link rel="stylesheet" href="Resources/css/modal.css">
    <link rel="shortcut icon" href="images/Logo.png" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<style>
    .highlight-category-sidebar {
        background: #aaa;
        color: red;
    }
    
    .info-container {
        width: 95%;
        margin-left: 2.5%;
        padding: 5px 2.5%;
        border: 1px solid #ddd;
        background-color: white;
    }
    .small-info {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .big-info {
        margin-top: 10px;
        display: none;
    }
    .show-big-info {
        display: block;
    }
    .big-info span {
        font-weight: 600;
    }
    .title-wrapper {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    
    
    .add-folder,
    .change_name {
        background: #8f8d8dd9;
        position: fixed;
        display: none;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 99;
    }
    .show-folder,
    .show-columns {
        display: block;
    }
    .folder-container,
    .change-container {
        background: white;
        border: 1px solid black;
        width: 40%;
        margin-left: 30%;
        margin-top: 100px;
        padding: 20px 20px;
        border-radius: 10px;
    }
    
    .folder-container button,
    .change-container button {
        background: transparent;
        border: none;
        margin-left: 15px;
        margin-top: 20px;
        cursor: pointer;
        color: blue;
    }
    
    .change-container input {
        margin-top: 20px;
        width: 100%;
        outline: none;
        border:none;
        border-bottom: 1px solid black;
    }
    
    .share_container {
        position: fixed;
        top: 100px;
        right: 50px;
        width: 300px;
        background: white;
        border: 1px solid black;
        padding: 10px;
        display: none;
    }
    .share_container input {
        outline: none;
        border: 1px solid black;
        border-radius: 1px;
        width: 90%;
        margin-left: 5%;
        border: none;
        border-bottom: 1px solid black;
        padding: 5px;
    }
    .share_container .close_share {
        float: right;
        font-size: 1.25rem;
        cursor: pointer;
    }
    
    .share_buttons {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 10px;
    }
    #share_readonly,
    #share_write {
        width: 45%;
        padding: 5px;
        border-radius: 1px;
        border 1px solid black;
        color: black;
        background: #eee;
    }
    #share_readonly {
        background: #ddd;
    } 
    
    #submit_share {
        width: 90%;
        margin-left:5%;
        border-radius: 1px;
        border: 1px solid black;
        background: cyan;
        color: black;
        font-size: 1rem;
        padding: 5px 5px;
        margin-top: 10px ;
        cursor: pointer;
    }
</style>
<body>
    
    <nav class="navbar" id="navbar">
        <div class="nav-left">
            <h3><a href="index.php">Account</a></h3>
        </div>
        <div class="nav-middle">
        </div>
        <div class="nav-right">
            <button onclick="lock_click()">
                <span class="material-symbols-outlined">
                    <?php
                        if($is_locked){
                            echo "lock";
                        }
                        else{
                            echo "lock_open";
                        }
                    ?>
                </span>
            </button>
            <button onclick="share_start()">
                <span class="material-symbols-outlined">
                    ios_share
                </span>
            </button>
            <button onclick="toggleEaseSidebar()">
                <span class="material-symbols-outlined">
                    menu
                </span>
            </button>
        </div>
    </nav>
    
    <section class="ease-sidebar" id="ease-sidebar">
        <span class="close-btn" onclick="toggleEaseSidebar()">×</span>
        <h2><?php 
            $sql = "
                SELECT plan
                FROM plans
                WHERE plan_id = {$_SESSION['plan_id']}
            ";
            global $con;
            $retval = mysqli_query($con, $sql);
            $item = mysqli_fetch_array($retval, MYSQLI_ASSOC);
            echo $item['plan'];
        ?></h2>
        <h4 id="ease-sidebar-id-h4"></h4>
        <div class="categories-container">
            <div class="categories-title-wrapper">
                <h3>Categories</h3>
                <div class="title-wrapper">
                    <span class="material-symbols-outlined" onclick="clear_category()">not_interested</span>
                    <span class="material-symbols-outlined" onclick="open_category_modal()">edit_note</span>
                </div>
            </div><hr><br>
            <ul class="categories-wrapper list-categories">
                <?php get_category_sidebar(); ?>
                <div class="add-category">
                    <input type="text" placeholder="Add Category">
                    <button onclick="add_category(this)"><span class="material-symbols-outlined">add</span></button>
                </div>
            </ul>
        </div>
        <br>
        <div class="categories-container entries-container" hidden>
            <div class="categories-title-wrapper">
                <h3>Entries</h3>
                <span class="material-symbols-outlined" onclick="open_entries_modal()">edit_note</span>
            </div><hr><br>
            <ul class="categories-wrapper entries-wrapper">
                <li>
                    <div class="left-link"><span class="material-symbols-outlined">push_pin</span></div>
                    <h4 id="entry-1">TFL Academy - R2000</h4>
                </li>
                <li>
                    <div class="left-link"><span class="material-symbols-outlined">push_pin</span></div>
                    <h4 id="entry-2">Cash Received - R10000</h4>
                </li>
                <li>
                    <div class="left-link"><span class="material-symbols-outlined">push_pin</span></div>
                    <h4 id="entry-3">Interest Received - R500</h4>
                </li>
                <li class="recent">
                    <div class="left-link"><span class="material-symbols-outlined">lightbulb</span></div>
                    <h4 id="entry-4">Helpmekaar - R7970</h4>
                </li>
                
            </ul>
        </div>
        <div class="info-container" hidden>
            <div class="small-info">
                <h3></h3>
                <span class="material-symbols-outlined" onclick="toggle_info_container(this)">expand_more</span></button>
            </div>
            <ul class="big-info">
                <li class="info-date">Date: <span></span></li>
                <li class="info-details">Details: <span></span></li>
                <li class="info-amount">Amount: <span></span></li>
                <li class="info-categories">Categories: <span></span></li>
            </ul>
        </div>
        <br>
        <div class="ease-bottom">
            <button onclick="logout()"><span class="material-symbols-outlined">logout</span>Log out</button>
            <button onclick="route(`index.php`)"><span class="material-symbols-outlined">home</span>Back Home</button>
        </div>
    </section>

    <section class="journal-sidebar" id="journal-sidebar">
        <div class="size-sidebar">
            <span class="material-symbols-outlined">
                fullscreen
            </span>
        </div>
        <ul class="journals">
            <?php get_statements_view(); ?>    

            <li onmouseover="showTooltip(this, 'Add Statement')"><button onclick="open_folder()"><span class="material-symbols-outlined">create_new_folder</span></button></li>
        </ul>
        <br>
        <hr>
        <br>
        <ul class="bottom">
            <li onmouseover="showTooltip(this, 'Edit Columns')"><span class="material-symbols-outlined">view_column</span></li>
            <li onmouseover="showTooltip(this, 'Info')"><span class="material-symbols-outlined">info</span></li>
            <li onmouseover="showTooltip(this, 'Edit')" onclick="open_columns()"><span class="material-symbols-outlined">edit_note</span></li>
            <li onmouseover="showTooltip(this, 'Dark mode')"><span class="material-symbols-outlined">contrast</span></li>
        </ul>
    </section>
    
    <main class="main"><br><br><br><br><br>
        <?php
            $menu = $_SESSION['menu'];
            if($menu != ""){
                require("Resources/tables/{$menu}.php");
            }
        ?>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    </main>

    <section class="categories-modal" hidden onclick="">
        <div class="modal-container">
            <span class="close-btn" onclick="close_category_modal()">×</span>
            <h1>All Categories</h1><hr><br>
            <div class="search-modal">
                <input type="text" placeholder="Search Category">
            </div>
            <br>
            <ul class="modal-wrapper categories-wrapper list_all_categories">
                
                <?php modalCategories(); ?>
            
                
            </ul>
            <div class="add-category">
                <input type="text" placeholder="Add Category">
                <button><span class="material-symbols-outlined">add</span></button>
            </div>
        </div>
    </section>

    <section class="entries-modal" hidden onclick="">
        <div class="modal-container">
            <span class="close-btn" onclick="close_entries_modal()">×</span>
            <h1>All Categories</h1><hr><br>
            <div class="search-modal">
                <input type="text" placeholder="Search Category">
            </div>
            <br>
            <ul class="modal-wrapper entries-wrapper">
                <li>
                    <div class="left-link"><span class="material-symbols-outlined">push_pin</span></div>
                    <h4 id="entry-1">TFL Academy - R2000</h4>
                </li>
                <li>
                    <div class="left-link"><span class="material-symbols-outlined">push_pin</span></div>
                    <h4 id="entry-2">Cash Received - R10000</h4>
                </li>
                <li>
                    <div class="left-link"><span class="material-symbols-outlined">push_pin</span></div>
                    <h4 id="entry-3">Interest Received - R500</h4>
                </li>
                <li class="recent">
                    <div class="left-link"><span class="material-symbols-outlined">lightbulb</span></div>
                    <h4 id="entry-4">Helpmekaar - R7970</h4>
                </li>
                
            </ul>
            
        </div>
    </section>

    <section class="finder">
        <div class="finder-left">
            <input id="finder-input" type="text" placeholder="Details - Ramount" value="Lets go">
            <span>1 of 28</span>
        </div>
        <div class="finder-right">
            <span class="material-symbols-outlined" onclick="decrease_finder()">expand_less</span>
            <span class="material-symbols-outlined" onclick="increase_finder()">expand_more</span>
            <span class="material-symbols-outlined" onclick="finder_close_2()">close</span>
        </div>
    </section>

    <section class="add-folder">
        <div class="folder-container">
            <h2>Add a table</h2>
            <select>
                <option value="crj">CRJ - Cash Received Journal</option>
                <option value="cpj">CPJ - Cash Paid Journal</option>
                <option value="arj">ARJ - Accounts Received Journal</option>
                <option value="apj">APJ - Accounts Paid Journal</option>
                <option value="gl">GL - General Ledger</option>
                <option value="apl">APL - Accounts Paid Ledger</option>
                <option value="arl">ARL - Accounts Received Ledger</option>
                <option value="ar">AR - Accounts Received</option>
                <option value="ap">AP - Accounts Paid</option>
            </select>
            <div class="folder-wrapper">
                <button onclick="cancel_folder()">Cancel</button>
                <button onclick="create_folder()">Create</button>
            </div>
        </div>
    </section>
    
    <section class="change_name">
        <div class="change-container">
            <h2>Change column name</h2>
            <input id="column_change" type="text" placeholder="New Column Names">
            <input id="column_chosen" type="text" readonly hidden>
            <div class="folder-wrapper">
                <button onclick="cancel_columns()">Cancel</button>
                <button onclick="save_columns()">Save</button>
            </div>
        </div>
    </section>
    <section class="share_container">
        <span class="close_share" onclick="share_start()">x</span><hr>
        <input placeholder="Email: " type="email">
        <div class="share_buttons">
            <button id="share_readonly" onclick="change_auth_share(this)">Read Only</button>
            <button id="share_write" onclick="change_auth_share(this)">Write and Edit</button>
        </div>
        <button id="submit_share" onclick = "share_end()">Share</button>
    </section>

    <!--  --><script src="Resources/js/app.js"></script>
    <!--  --><script src="Resources/js/table.js"></script>
    
    <script>
        keyboard_Shortcuts();
        
        window.scrollTo(0, document.body.scrollHeight);
        
link_gl_to_journal();
function link_gl_to_journal(){
    document.querySelectorAll(".balance-cf .amount input").forEach(object => {
        if(object != ""){
            const row = object.parentElement.parentElement;
            
            // Route it to the route.php file where you change the plan_id and then have it also give sessions for the year and the month
        }
    });
}

function lock_click(){
    window.location.href = "Resources/functions/lock.php";
}

function share_start(){
    const share = document.querySelector(".share_container");
    share.style.display = share.style.display == "none"? "block":"none";
}

function share_end(){
    const input = document.querySelector(".share_container input");
    let button = "readonly";
    if (document.querySelector("#share_write").style.background == "#ddd"){
        button = "write"
    }
    window.location.href = "Resources/functions/share.php?input=" + input.value + "&button" + button;
}

function change_auth_share(e){
    if(e.id == "share_readonly"){
        document.querySelector("#share_write").style.background = "#eee";
        e.style.background = "#ddd";
    }
    else if(e.id == "share_write") {
        document.querySelector("#share_readonly").style.background = "#eee";
        e.style.background = "#ddd";
    }
}
        
    </script>

</body>
</html
