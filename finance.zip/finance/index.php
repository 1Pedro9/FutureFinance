<?php
    session_start();
    require("config.php");
    require("function.php");

    if(auth_admin() || isset($_SESSION['member_id'])){
        
    }
    else {
        header("location: Resources/php/login.html");
    }
    
    if($_SESSION['lock_plan'] == "open" || !isset($_SESSION['lock_plan'])){
        
    }
    else{
        header("location: view.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Future Finance - FTA</title>
    <link rel="stylesheet" href="Resources/css/styles.css">
    <link rel="stylesheet" href="Resources/css/navbar.css">
    <link rel="shortcut icon" href="images/Logo.png" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>
<body>
    <nav class="navbar">
        <div class="nav-left">

        </div>
        <div class="nav-middle">
            <h3><a href="index.php">Future Finance</a></h3>
        </div>
        <div class="nav-right">
            <button onclick="toggleSidebar()">
                <span class="material-symbols-outlined">
                    menu
                </span>
            </button>
        </div>
    </nav>
    
    <section class="sidebar" id="sidebar">
        <span class="close-btn" onclick="toggleSidebar()">×</span>
        <h2>Accounts</h2>
        <ul id="accountList">
            <?php get_statements_sidebar(); ?>
        </ul>
    </section>

    <main class="main"><br><br>
        <div class='message'>
            <h2 class='title'>Welcome: <?php get_member_name(); ?></h2>
            <div class="stats-container">
                <canvas id="bank_status"></canvas>
                <div class="status-container">
                    R<span id="income"><?php echo round(get_total("crj"), 2); ?></span><br><br>
                    R<span id="expenses"><?php echo round(get_total("cpj"), 2); ?></span>
                </div>
            </div>
        </div>
        <div class="account-info">
            <h3 class="value">Your Account Value: R<span><?php echo round((get_total("crj") - get_total("cpj")), 2); ?></span></h3>
            <h3 class="worth">Your Net Worth: R<span><?php echo round((get_total("crj") - get_total("cpj")), 2); ?></span></h3>
        </div>
        <div class="link-buttons">
            <?php get_statements_main(); ?>
        
            <button>
                <input type="text" placeholder="Add Statement">
                <span class="material-symbols-outlined" onclick="add_statement(this)"  onmouseover="showTooltip(this, 'Add Statement')">
                    add_business
                </span>
            </button>
        </div>
    </main>

    <footer class="footer">

    </footer>

    <script src="Resources/js/app.js"></script>
    <script>
        canvas();
    </script>
</body>
</html>