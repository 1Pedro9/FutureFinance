<?php

    function auth_admin(){
        global $con;
        if (isset($_SESSION['email'])) {
    
            $x = $_SESSION['email'];
            $sql = "SELECT `is_admin`, `member_id` FROM `members` WHERE `email`='$x'";
            $retval = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($retval, MYSQLI_ASSOC);
            $check = $row['is_admin'];
            $_SESSION['member_id'] = $row['member_id'];
            
            if ($check == 1) {
    
                return true;
            } else {
    
                return false;
            }
        } else {
            return false;
        }
    }
    
    function get_statements_sidebar(){
        $member_id = $_SESSION['member_id'];
        $sql = "
            SELECT *
            FROM plans
            WHERE member_id = $member_id
        ";
        global $con;
        $retval = mysqli_query($con, $sql);
        $string = "";
        while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)){
            $plan = $row['plan'];
            $string .= '
                <li>
                    <div onclick="show_journals(this)">' . $plan . '</div>
                    <ul class="journals" hidden>
            ';
            
            $plan_id = $row['plan_id'];
            $sql = "
                SELECT * 
                FROM tables
                WHERE plan_id = $plan_id AND member_id = $member_id
            ";
            global $con;
            $retval2 = mysqli_query($con, $sql);
            while($row2 = mysqli_fetch_array($retval2, MYSQLI_ASSOC)){
                $table = $row2['table_name'];
                $string .= '
                    <li>' . $table . '</li>
                ';
            }

            $string .= '
                    </ul>
                </li>
            ';
        }
        echo $string;
    }

    function get_member_name(){
        $member_id = $_SESSION['member_id'];
        $sql = "
            SELECT *
            FROM members
            WHERE member_id = $member_id
        ";
        global $con;
        $retval = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($retval, MYSQLI_ASSOC);
        $fname = $row['first_name'];
        $lname = $row['last_name'];
        echo "$fname $lname";
    }

    function get_total($table){
        $member_id = $_SESSION['member_id'];
        $sql = "
            SELECT SUM(amount)
            FROM $table
            WHERE member_id = $member_id
        ";
        global $con;
        $retval = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($retval, MYSQLI_ASSOC);
        return $row['SUM(amount)'];
    }

    function get_statements_main(){
        $member_id = $_SESSION['member_id'];
        $sql = "
            SELECT *
            FROM plans
            WHERE member_id = $member_id
        ";
        global $con;
        $retval = mysqli_query($con, $sql);
        $string = "";
        while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)){
            $plan = $row['plan'];
            $plan_id = $row['plan_id'];
            $string .= '
                <button>
                    <span class="material-symbols-outlined" onclick="remove_statement(this)"  onmouseover="showTooltip(this, `Delete Statement`)">
                        delete
                    </span>
                    <a href="Resources/functions/route.php?plan=' . $plan_id . '">' . $plan . '</a>
                </button>
            ';
        }
        echo $string;
    }

    function get_statements_view(){
        $member_id = $_SESSION['member_id'];
        $plan_id = $_SESSION['plan_id'];
        
        $sql = "
            SELECT *
            FROM tables
            WHERE member_id = $member_id AND plan_id = $plan_id
        ";
        global $con;
        $retval = mysqli_query($con, $sql);
        $string = "";
        while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)){
            $table = $row['table_name'];
            $string .= '<li onmouseover="showTooltip(this, ``)" onclick="set_menu(`' . $table . '`)"><button>' . strtoupper($table) . '</button></li>';
        }
        echo $string;
    }
    
    function get_category_sidebar(){
        $member_id = $_SESSION['member_id'];
        $plan_id = $_SESSION['plan_id'];
        $menu = $_SESSION['menu'];
        $sql = "
            SELECT *
            FROM categories
            WHERE member_id = $member_id
            AND plan_id = $plan_id
            AND table_name = '$menu'
            LIMIT 5
        ";
        global $con;
        $retval = mysqli_query($con, $sql);
        while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)){
            echo '
                <li>
                    <div class="left-link"><span class="material-symbols-outlined">push_pin</span></div>
                    <h4>' . $row['category'] . '</h4>
                    <input class="color-picker" value="' . $row['color'] . '" type="color" onchange="update_category_color(this)">
                </li>
            ';
        }
    }
    
    function modalCategories(){
        $member_id = $_SESSION['member_id'];
        $plan_id = $_SESSION['plan_id'];
        $menu = $_SESSION['menu'];
        $sql = "
            SELECT *
            FROM categories
            WHERE member_id = $member_id
            AND plan_id = $plan_id
            AND table_name = '$menu'
        ";
        global $con;
        $retval = mysqli_query($con, $sql);
        while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)){
            echo '
                <li>
                    <div class="left-link"><span class="material-symbols-outlined">push_pin</span></div>
                    <h4>' . $row['category'] . '</h4>
                    <input class="color-picker" value="' . $row['color'] . '" type="color" onchange="update_category_color(this)">
                </li>
            ';
        }
    }
    
    function get_entries(){
        $member_id = $_SESSION['member_id'];
        $plan_id = $_SESSION['plan_id'];
        $menu = $_SESSION['menu'];
        
    }

?>